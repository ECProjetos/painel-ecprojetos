"use client";

import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { buttonVariants } from "@/components/ui/button";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import { PlusCircle } from "lucide-react";
import Link from "next/link";
import { getAllColaboradores } from "@/app/actions/colaboradores";
import { useEffect, useState } from "react";
import { ColaboradorView } from "@/types/colaboradores";
import { ColaboradorTable } from "@/components/colaboradores/table";
import { colaboradoresColumns } from "@/components/colaboradores/columns";
import { SkeletonTable } from "@/components/skeleton-table";

export function ColaboradoresPage() {
  const [colaboradores, setColaboradores] = useState<ColaboradorView[]>([]);
  const [loading, setLoading] = useState(true);
  const [refresh, setRefresh] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    async function fetchColaboradores() {
      try {
        setLoading(true);
        setErrorMessage(null);

        const data = await getAllColaboradores();
        setColaboradores(data ?? []);
      } catch (error) {
        console.error("Erro ao buscar colaboradores:", error);
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Erro ao carregar colaboradores."
        );
        setColaboradores([]);
      } finally {
        setLoading(false);
      }
    }

    fetchColaboradores();
  }, [refresh]);

  return (
    <div className="bg-white shadow-lg rounded-2xl p-6 w-full min-h-full border dark:bg-[#1c1c20]">
      <div className="flex h-16 shrink-0 items-center gap-2 px-4">
        <SidebarTrigger className="-ml-1" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href="/controle-horarios/inicio">
                  Controle de Horários
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href="/controle-horarios/gestao/painel-equipes">
                  Gestão
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbPage>Colaboradores</BreadcrumbPage>
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      <div className="space-y-4 mt-4">
        <div className="flex items-center align-center justify-between px-4">
          <h1 className="text-2xl font-bold">Gestão de Colaboradores</h1>
          <div className="flex items-center space-x-2">
            <Link
              href="/controle-horarios/gestao/colaboradores/novo"
              className={cn(buttonVariants({ variant: "default" }))}
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Colaborador
            </Link>
          </div>
        </div>

        {loading ? (
          <SkeletonTable />
        ) : errorMessage ? (
          <div className="px-4 py-6 text-sm text-red-600 border rounded-md bg-red-50">
            Erro ao carregar colaboradores: {errorMessage}
          </div>
        ) : (
          <div className="overflow-auto">
            <ColaboradorTable
              data={colaboradores}
              columns={colaboradoresColumns({
                onUpdate: () => setRefresh((prev) => prev + 1),
              })}
            />
          </div>
        )}
      </div>
    </div>
  );
}