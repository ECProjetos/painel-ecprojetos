"use client"

import { useEffect, useMemo, useState } from "react"
import { getRelatoriosIndicadores } from "@/app/actions/indicadores"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Download, FileText } from "lucide-react"
import { toast } from "sonner"

type Relatorio = {
  colaborador_id: string
  colaborador_nome: string
  equipe: string | null
  ano: number
  trimestre: number
  total_entregas: number
  IES: number
  IP: number
  IQ: number
  IEV: number
  IDI: number
  status_trimestre: string | null
  status_acumulado_ano: string | null
}

function formatNumber(value: number | null | undefined) {
  return Number(value ?? 0).toFixed(2)
}

export default function IndicadoresRelatorios() {
  const [relatorios, setRelatorios] = useState<Relatorio[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      try {
        setLoading(true)
        const data = await getRelatoriosIndicadores()
        setRelatorios(data as Relatorio[])
      } catch (error) {
        console.error(error)
        toast.error("Não foi possível carregar os relatórios.")
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [])

  const csvContent = useMemo(() => {
    const header = [
      "Colaborador",
      "Equipe",
      "Ano",
      "Trimestre",
      "Entregas",
      "IES",
      "IP",
      "IQ",
      "IEV",
      "IDI",
      "Status Trimestre",
      "Status Acumulado Ano",
    ]

    const rows = relatorios.map((item) => [
      item.colaborador_nome,
      item.equipe ?? "",
      item.ano,
      item.trimestre,
      item.total_entregas,
      formatNumber(item.IES),
      formatNumber(item.IP),
      formatNumber(item.IQ),
      formatNumber(item.IEV),
      formatNumber(item.IDI),
      item.status_trimestre ?? "",
      item.status_acumulado_ano ?? "",
    ])

    return [header, ...rows]
      .map((row) =>
        row
          .map((cell) => `"${String(cell).replaceAll('"', '""')}"`)
          .join(";"),
      )
      .join("\n")
  }, [relatorios])

  function baixarCsv() {
    const blob = new Blob([`\uFEFF${csvContent}`], {
      type: "text/csv;charset=utf-8;",
    })

    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")

    link.href = url
    link.download = "relatorios-indicadores.csv"
    link.click()

    URL.revokeObjectURL(url)
  }

  return (
    <Card className="rounded-2xl border bg-card p-6 shadow-sm">
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Relatórios</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Relatórios consolidados por colaborador, ano e trimestre.
          </p>
        </div>

        <Button
          type="button"
          variant="outline"
          onClick={baixarCsv}
          disabled={!relatorios.length}
        >
          <Download className="mr-2 h-4 w-4" />
          Exportar CSV
        </Button>
      </div>

      <div className="mt-6 overflow-hidden rounded-xl border">
        {loading ? (
          <div className="p-4 text-sm text-muted-foreground">
            Carregando relatórios...
          </div>
        ) : relatorios.length === 0 ? (
          <div className="p-4 text-sm text-muted-foreground">
            Nenhum relatório encontrado no banco de dados.
          </div>
        ) : (
          <div className="max-h-[560px] overflow-auto">
            <table className="w-full min-w-[1100px] text-sm">
              <thead className="sticky top-0 bg-muted">
                <tr className="border-b">
                  <th className="px-4 py-3 text-left font-semibold">
                    Colaborador
                  </th>
                  <th className="px-4 py-3 text-left font-semibold">
                    Equipe
                  </th>
                  <th className="px-4 py-3 text-center font-semibold">Ano</th>
                  <th className="px-4 py-3 text-center font-semibold">
                    Trimestre
                  </th>
                  <th className="px-4 py-3 text-center font-semibold">
                    Entregas
                  </th>
                  <th className="px-4 py-3 text-center font-semibold">IES</th>
                  <th className="px-4 py-3 text-center font-semibold">IP</th>
                  <th className="px-4 py-3 text-center font-semibold">IQ</th>
                  <th className="px-4 py-3 text-center font-semibold">IEV</th>
                  <th className="px-4 py-3 text-center font-semibold">IDI</th>
                  <th className="px-4 py-3 text-center font-semibold">
                    Status
                  </th>
                </tr>
              </thead>

              <tbody>
                {relatorios.map((item) => (
                  <tr
                    key={`${item.colaborador_id}-${item.ano}-${item.trimestre}`}
                    className="border-b last:border-b-0"
                  >
                    <td className="px-4 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-violet-500" />
                        {item.colaborador_nome}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {item.equipe ?? "-"}
                    </td>
                    <td className="px-4 py-3 text-center">{item.ano}</td>
                    <td className="px-4 py-3 text-center">
                      {item.trimestre}º
                    </td>
                    <td className="px-4 py-3 text-center">
                      {item.total_entregas}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {formatNumber(item.IES)}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {formatNumber(item.IP)}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {formatNumber(item.IQ)}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {formatNumber(item.IEV)}
                    </td>
                    <td className="px-4 py-3 text-center font-semibold">
                      {formatNumber(item.IDI)}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {item.status_trimestre ?? "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Card>
  )
}