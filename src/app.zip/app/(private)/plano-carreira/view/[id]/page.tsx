import { FeedbackTable } from "@/components/plano-carreira/feedback-table";

export default function ViewColaboradorPage() {
    return (
        <div className="m-10">
            <FeedbackTable />
        </div>
    );
}