"use client";

import AllNps from "@/components/satisfacao/all-nps";
import CriarNpsForm from "@/components/satisfacao/form-nps";


export default function CriarNpsPage() {



    return (
        <>
            <CriarNpsForm />
            <AllNps />
        </>
    );
};
